extends SceneTree
var failures: Array[String] = []
var passed: Array[String] = []
func check(value: bool, description: String) -> void:
	if value: passed.append(description);print("PASS ",description)
	else: failures.append(description);push_error(description)
func frames(count: int) -> void:
	for i in range(count):await physics_frame
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var scene = load("res://scenes/visual_sample.tscn").instantiate()
	root.add_child(scene)
	await frames(3)
	var human=scene.human
	human.automated=true
	human.position=Vector2(400,400);human.direction=Vector2.RIGHT
	await frames(61)
	var straight: float=human.position.distance_to(Vector2(400,400))
	human.position=Vector2(400,400);human.direction=Vector2.ONE
	await frames(61)
	var diagonal: float=human.position.distance_to(Vector2(400,400))
	check(absf(straight-diagonal)<0.1 and straight>90,"actual diagonal displacement equals cardinal displacement")
	human.direction=Vector2.ZERO;await frames(2)
	var stopped: Vector2=human.position;await frames(20)
	check(human.position.distance_to(stopped)<0.01,"released input stops movement")
	check(human.facing=="toward","diagonal tie chooses vertical facing and idle retains it")
	human.position=Vector2(1110,400);human.direction=Vector2.RIGHT;await frames(60)
	check(human.position.x<1121 and human.position.x>1110,"wall blocks actual player displacement")
	for pair in [[Vector2.LEFT,"left"],[Vector2.RIGHT,"right"],[Vector2.UP,"away"],[Vector2.DOWN,"toward"]]:
		human.position=Vector2(640,440);human.direction=pair[0];await frames(2)
		check(human.facing==pair[1],"facing "+pair[1])
	paused=true;await frames(2);var freeze: Vector2=human.position;var clock: float=scene.elapsed
	await frames(30);check(human.position==freeze and scene.elapsed==clock,"explicit tree pause halts player and demo clock")
	paused=false
	var key:=InputEventKey.new();key.physical_keycode=KEY_R;key.pressed=true;scene._unhandled_key_input(key)
	check(human.position==Vector2(640,440) and scene.elapsed==0,"reset restores initial position and clock")
	var report={"passed":passed,"failed":failures,"not_run":["pet routes","doorway occlusion","interaction range","held preparation","shield cleanup","cabinet repeatability","owner verdict"],"scope":"T01 only"}
	var result_path:=OS.get_environment("S02_CHECKS_PATH")
	if not result_path.is_empty():
		var f:=FileAccess.open(result_path,FileAccess.WRITE);f.store_string(JSON.stringify(report,"  "))
	quit(0 if failures.is_empty() else 1)
