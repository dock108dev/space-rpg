extends Node2D

var human: CharacterBody2D
var label := Label.new()
var elapsed := 0.0
var demo := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for action in {"left":[KEY_A,KEY_LEFT],"right":[KEY_D,KEY_RIGHT],"up":[KEY_W,KEY_UP],"down":[KEY_S,KEY_DOWN]}:
		if not InputMap.has_action(action): InputMap.add_action(action)
		for key in {"left":[KEY_A,KEY_LEFT],"right":[KEY_D,KEY_RIGHT],"up":[KEY_W,KEY_UP],"down":[KEY_S,KEY_DOWN]}[action]:
			var event := InputEventKey.new();event.physical_keycode=key;InputMap.action_add_event(action,event)
	human = load("res://scripts/human_controller.gd").new()
	human.name="Human";human.position=Vector2(640,440);human.process_mode=Node.PROCESS_MODE_PAUSABLE
	add_child(human)
	for rect in [Rect2(150,180,980,15),Rect2(150,650,980,15),Rect2(140,180,15,485),Rect2(1130,180,15,485)]:
		var wall := StaticBody2D.new();wall.position=rect.get_center()
		var c := CollisionShape2D.new();var shape := RectangleShape2D.new();shape.size=rect.size;c.shape=shape;wall.add_child(c);add_child(wall)
	label.position=Vector2(40,30);label.add_theme_font_size_override("font_size",22);add_child(label)
	demo = "--motion-demo" in OS.get_cmdline_user_args()
	human.automated=demo
	print("VISIBLE_ENV ",JSON.stringify({"window":DisplayServer.window_get_size(),"screen":DisplayServer.screen_get_size(),"scale":DisplayServer.screen_get_scale(),"renderer":RenderingServer.get_current_rendering_method()}))

func _process(delta: float) -> void:
	if not get_tree().paused:
		elapsed+=delta
		if demo:
			var sequence := [Vector2.RIGHT,Vector2.ZERO,Vector2.DOWN,Vector2.ZERO,Vector2.LEFT,Vector2.ZERO,Vector2.UP,Vector2.ZERO]
			human.direction=sequence[int(elapsed/1.3)%sequence.size()]
	label.text="VIS–001 / T01    •    Human motion study\nWASD / arrows: move    R: reset    Esc: pause    M: motion loop\n"+("PAUSED" if get_tree().paused else "")
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():return
	if event.physical_keycode==KEY_ESCAPE:get_tree().paused=not get_tree().paused
	if event.physical_keycode==KEY_R:
		human.position=Vector2(640,440);elapsed=0;human.direction=Vector2.ZERO
	if event.physical_keycode==KEY_M:
		demo=not demo;human.automated=demo

func _draw() -> void:
	draw_rect(Rect2(150,180,980,485),Color("8a8875"))
	for y in range(180,665,40):draw_line(Vector2(150,y),Vector2(1130,y),Color("777864"),1)
	for x in range(150,1130,60):draw_line(Vector2(x,180),Vector2(x,665),Color("777864"),1)
	if is_instance_valid(human):
		draw_set_transform(human.position,0,Vector2(1,0.3));draw_circle(Vector2.ZERO,15,Color(0,0,0,0.18));draw_set_transform(Vector2.ZERO)
